package com.entity.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the USERDETAILS1 database table.
 * 
 */
@Entity
@NamedQuery(name="Userdetails1.findAll", query="SELECT u FROM Userdetails1 u")
public class Userdetails1 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long referenceid;

	private String adharcard;

	@Temporal(TemporalType.DATE)
	private Date dob;

	@Column(name="E_MAIL_ID")
	private String eMailId;

	private String fathersname;

	private String firstname;

	private BigDecimal grossannualincome;

	private String lastname;

	private String mobileno;

	private String occupationtype;

	@Column(name="PERM_ADDRESSLINE1")
	private String permAddressline1;

	@Column(name="PERM_ADDRESSLINE2")
	private String permAddressline2;

	@Column(name="PERM_CITY")
	private String permCity;

	@Column(name="PERM_STATE")
	private String permState;

	@Column(name="PERM_ZIPCODE")
	private int permZipcode;

	@Column(name="PRES_ADDRESSLINE1")
	private String presAddressline1;

	@Column(name="PRES_ADDRESSLINE2")
	private String presAddressline2;

	@Column(name="PRES_CITY")
	private String presCity;

	@Column(name="PRES_STATE")
	private String presState;

	@Column(name="PRES_ZIPCODE")
	private int presZipcode;

	private String sourceofincome;

	//bi-directional many-to-one association to LoginDetail
	@OneToMany(mappedBy="userdetails1")
	private List<LoginDetail> loginDetails;

	public Userdetails1() {
	}

	public long getReferenceid() {
		return this.referenceid;
	}

	public void setReferenceid(long referenceid) {
		this.referenceid = referenceid;
	}

	public String getAdharcard() {
		return this.adharcard;
	}

	public void setAdharcard(String adharcard) {
		this.adharcard = adharcard;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getEMailId() {
		return this.eMailId;
	}

	public void setEMailId(String eMailId) {
		this.eMailId = eMailId;
	}

	public String getFathersname() {
		return this.fathersname;
	}

	public void setFathersname(String fathersname) {
		this.fathersname = fathersname;
	}

	public String getFirstname() {
		return this.firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public BigDecimal getGrossannualincome() {
		return this.grossannualincome;
	}

	public void setGrossannualincome(BigDecimal grossannualincome) {
		this.grossannualincome = grossannualincome;
	}

	public String getLastname() {
		return this.lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getMobileno() {
		return this.mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public String getOccupationtype() {
		return this.occupationtype;
	}

	public void setOccupationtype(String occupationtype) {
		this.occupationtype = occupationtype;
	}

	public String getPermAddressline1() {
		return this.permAddressline1;
	}

	public void setPermAddressline1(String permAddressline1) {
		this.permAddressline1 = permAddressline1;
	}

	public String getPermAddressline2() {
		return this.permAddressline2;
	}

	public void setPermAddressline2(String permAddressline2) {
		this.permAddressline2 = permAddressline2;
	}

	public String getPermCity() {
		return this.permCity;
	}

	public void setPermCity(String permCity) {
		this.permCity = permCity;
	}

	public String getPermState() {
		return this.permState;
	}

	public void setPermState(String permState) {
		this.permState = permState;
	}

	public int getPermZipcode() {
		return this.permZipcode;
	}

	public void setPermZipcode(int permZipcode) {
		this.permZipcode = permZipcode;
	}

	public String getPresAddressline1() {
		return this.presAddressline1;
	}

	public void setPresAddressline1(String presAddressline1) {
		this.presAddressline1 = presAddressline1;
	}

	public String getPresAddressline2() {
		return this.presAddressline2;
	}

	public void setPresAddressline2(String presAddressline2) {
		this.presAddressline2 = presAddressline2;
	}

	public String getPresCity() {
		return this.presCity;
	}

	public void setPresCity(String presCity) {
		this.presCity = presCity;
	}

	public String getPresState() {
		return this.presState;
	}

	public void setPresState(String presState) {
		this.presState = presState;
	}

	public int getPresZipcode() {
		return this.presZipcode;
	}

	public void setPresZipcode(int presZipcode) {
		this.presZipcode = presZipcode;
	}

	public String getSourceofincome() {
		return this.sourceofincome;
	}

	public void setSourceofincome(String sourceofincome) {
		this.sourceofincome = sourceofincome;
	}

	public List<LoginDetail> getLoginDetails() {
		return this.loginDetails;
	}

	public void setLoginDetails(List<LoginDetail> loginDetails) {
		this.loginDetails = loginDetails;
	}

	public LoginDetail addLoginDetail(LoginDetail loginDetail) {
		getLoginDetails().add(loginDetail);
		loginDetail.setUserdetails1(this);

		return loginDetail;
	}

	public LoginDetail removeLoginDetail(LoginDetail loginDetail) {
		getLoginDetails().remove(loginDetail);
		loginDetail.setUserdetails1(null);

		return loginDetail;
	}

}