package com.entity.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the FUND_TRANSFER1 database table.
 * 
 */
@Entity
@Table(name="FUND_TRANSFER1")
@NamedQuery(name="FundTransfer1.findAll", query="SELECT f FROM FundTransfer1 f")
public class FundTransfer1 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long transactionid;

	private double amount;

	@Temporal(TemporalType.DATE)
	private Date datee;

	@Column(name="TRANSACTION_REMARKS")
	private String transactionRemarks;

	private String transactionmode;

	private String transactiontype;

	//bi-directional many-to-one association to Payeedetail
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="ACCOUNTNO", referencedColumnName="ACCOUNTNO"),
		@JoinColumn(name="PAYEEACCOUNTNO", referencedColumnName="PAYEEACCOUNTNO")
		})
	private Payeedetail payeedetail;

	public FundTransfer1() {
	}

	public long getTransactionid() {
		return this.transactionid;
	}

	public void setTransactionid(long transactionid) {
		this.transactionid = transactionid;
	}

	public double getAmount() {
		return this.amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Date getDatee() {
		return this.datee;
	}

	public void setDatee(Date datee) {
		this.datee = datee;
	}

	public String getTransactionRemarks() {
		return this.transactionRemarks;
	}

	public void setTransactionRemarks(String transactionRemarks) {
		this.transactionRemarks = transactionRemarks;
	}

	public String getTransactionmode() {
		return this.transactionmode;
	}

	public void setTransactionmode(String transactionmode) {
		this.transactionmode = transactionmode;
	}

	public String getTransactiontype() {
		return this.transactiontype;
	}

	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}

	public Payeedetail getPayeedetail() {
		return this.payeedetail;
	}

	public void setPayeedetail(Payeedetail payeedetail) {
		this.payeedetail = payeedetail;
	}

}