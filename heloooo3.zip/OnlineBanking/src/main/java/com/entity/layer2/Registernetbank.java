package com.entity.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the REGISTERNETBANK database table.
 * 
 */
@Entity
@NamedQuery(name="Registernetbank.findAll", query="SELECT r FROM Registernetbank r")
public class Registernetbank implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="USER_ID")
	private long userId;

	@Column(name="ACCOUNT_NO")
	private BigDecimal accountNo;

	@Column(name="LOGIN_PASSWORD")
	private String loginPassword;

	private BigDecimal referenceid;

	@Column(name="TRANSACTION_PASSWORD")
	private String transactionPassword;

	//bi-directional many-to-one association to LoginDetail
	@OneToMany(mappedBy="registernetbank")
	private List<LoginDetail> loginDetails;

	//bi-directional many-to-one association to Masteraccount
	@OneToMany(mappedBy="registernetbank")
	private List<Masteraccount> masteraccounts;

	//bi-directional many-to-one association to Payeedetail
	@OneToMany(mappedBy="registernetbank")
	private List<Payeedetail> payeedetails;

	public Registernetbank() {
	}

	public long getUserId() {
		return this.userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public BigDecimal getAccountNo() {
		return this.accountNo;
	}

	public void setAccountNo(BigDecimal accountNo) {
		this.accountNo = accountNo;
	}

	public String getLoginPassword() {
		return this.loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public BigDecimal getReferenceid() {
		return this.referenceid;
	}

	public void setReferenceid(BigDecimal referenceid) {
		this.referenceid = referenceid;
	}

	public String getTransactionPassword() {
		return this.transactionPassword;
	}

	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}

	public List<LoginDetail> getLoginDetails() {
		return this.loginDetails;
	}

	public void setLoginDetails(List<LoginDetail> loginDetails) {
		this.loginDetails = loginDetails;
	}

	public LoginDetail addLoginDetail(LoginDetail loginDetail) {
		getLoginDetails().add(loginDetail);
		loginDetail.setRegisternetbank(this);

		return loginDetail;
	}

	public LoginDetail removeLoginDetail(LoginDetail loginDetail) {
		getLoginDetails().remove(loginDetail);
		loginDetail.setRegisternetbank(null);

		return loginDetail;
	}

	public List<Masteraccount> getMasteraccounts() {
		return this.masteraccounts;
	}

	public void setMasteraccounts(List<Masteraccount> masteraccounts) {
		this.masteraccounts = masteraccounts;
	}

	public Masteraccount addMasteraccount(Masteraccount masteraccount) {
		getMasteraccounts().add(masteraccount);
		masteraccount.setRegisternetbank(this);

		return masteraccount;
	}

	public Masteraccount removeMasteraccount(Masteraccount masteraccount) {
		getMasteraccounts().remove(masteraccount);
		masteraccount.setRegisternetbank(null);

		return masteraccount;
	}

	public List<Payeedetail> getPayeedetails() {
		return this.payeedetails;
	}

	public void setPayeedetails(List<Payeedetail> payeedetails) {
		this.payeedetails = payeedetails;
	}

	public Payeedetail addPayeedetail(Payeedetail payeedetail) {
		getPayeedetails().add(payeedetail);
		payeedetail.setRegisternetbank(this);

		return payeedetail;
	}

	public Payeedetail removePayeedetail(Payeedetail payeedetail) {
		getPayeedetails().remove(payeedetail);
		payeedetail.setRegisternetbank(null);

		return payeedetail;
	}

}