package com.entity.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the ADMININPUTS database table.
 * 
 */
@Entity
@Table(name="ADMININPUTS")
@NamedQuery(name="Admininput.findAll", query="SELECT a FROM Admininput a")
public class Admininput implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long referenceid;

	@Column(name="ACCOUNT_NO")
	private String accountNo;

	@Column(name="ADMIN_REMARKS")
	private String adminRemarks;

	@Temporal(TemporalType.DATE)
	private Date applicationdate;

	private String approval;

	public Admininput() {
	}

	public long getReferenceid() {
		return this.referenceid;
	}

	public void setReferenceid(long referenceid) {
		this.referenceid = referenceid;
	}

	public String getAccountNo() {
		return this.accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAdminRemarks() {
		return this.adminRemarks;
	}

	public void setAdminRemarks(String adminRemarks) {
		this.adminRemarks = adminRemarks;
	}

	public Date getApplicationdate() {
		return this.applicationdate;
	}

	public void setApplicationdate(Date applicationdate) {
		this.applicationdate = applicationdate;
	}

	public String getApproval() {
		return this.approval;
	}

	public void setApproval(String approval) {
		this.approval = approval;
	}

}