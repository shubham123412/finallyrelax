package com.entity.layer2;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the PAYEEDETAILS database table.
 * 
 */
@Embeddable
public class PayeedetailPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private long accountno;

	private long payeeaccountno;

	public PayeedetailPK() {
	}
	public long getAccountno() {
		return this.accountno;
	}
	public void setAccountno(long accountno) {
		this.accountno = accountno;
	}
	public long getPayeeaccountno() {
		return this.payeeaccountno;
	}
	public void setPayeeaccountno(long payeeaccountno) {
		this.payeeaccountno = payeeaccountno;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PayeedetailPK)) {
			return false;
		}
		PayeedetailPK castOther = (PayeedetailPK)other;
		return 
			(this.accountno == castOther.accountno)
			&& (this.payeeaccountno == castOther.payeeaccountno);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.accountno ^ (this.accountno >>> 32)));
		hash = hash * prime + ((int) (this.payeeaccountno ^ (this.payeeaccountno >>> 32)));
		
		return hash;
	}
}