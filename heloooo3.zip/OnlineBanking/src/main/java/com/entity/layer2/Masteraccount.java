package com.entity.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the MASTERACCOUNT database table.
 * 
 */
@Entity
@NamedQuery(name="Masteraccount.findAll", query="SELECT m FROM Masteraccount m")
public class Masteraccount implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long accountno;

	private BigDecimal balance;

	//bi-directional many-to-one association to Registernetbank
	@ManyToOne
	@JoinColumn(name="USER_ID")
	private Registernetbank registernetbank;

	public Masteraccount() {
	}

	public long getAccountno() {
		return this.accountno;
	}

	public void setAccountno(long accountno) {
		this.accountno = accountno;
	}

	public BigDecimal getBalance() {
		return this.balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public Registernetbank getRegisternetbank() {
		return this.registernetbank;
	}

	public void setRegisternetbank(Registernetbank registernetbank) {
		this.registernetbank = registernetbank;
	}

}