package com.entity.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.entity.layer2.FundTransfer1;

@Repository
public class Fund_Transfer1RepositoryImpl implements Fund_transfer1Repository{
	
	@PersistenceContext
	EntityManager entityManager;

	//@Transactional
	//public void add(Fund_Transfer1 Fund_transfer1) {
	//	// TODO Auto-generated method stub
		
//	}

	@Transactional
	public List<FundTransfer1> getAll() {
		
		String s="from FundTransfer1";
		Query query = entityManager.createQuery(s);
		List<FundTransfer1> Fund_Transfer1=query.getResultList();
		return Fund_Transfer1;
	}

	@Override
	public void add(FundTransfer1 Fund_transfer1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public FundTransfer1 get(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
//	public Fund_Transfer1 get(int Transactionid) {
//		// TODO Auto-generated method stub
//		return null;
//	}

//	@Override
//	public List<Fund_Transfer1> getAll() {
//		// TODO Auto-generated method stub
//		return null;
	//}

}
