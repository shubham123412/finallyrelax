package com.entity.layer3;

import java.util.List;

import com.entity.layer2.FundTransfer1;



public interface Fund_transfer1Repository {

	public void add(FundTransfer1 Fund_transfer1 );
	public FundTransfer1 get(int productId);
	public List<FundTransfer1> getAll();
	//7 methods declared
	
}
