package com.entity.layer3;

import java.util.List;

import com.entity.layer2.FundTransfer2;

//import com.entity.Fund_Transfer1;

//public interface Fund_transfer2Repository {
	
//	public void add(Fund_Transfer2 Fund_transfer1 );
//	public Fund_Transfer2 get(int Transactionid);
//	public List<Fund_Transfer2> getAll();
	

//}
