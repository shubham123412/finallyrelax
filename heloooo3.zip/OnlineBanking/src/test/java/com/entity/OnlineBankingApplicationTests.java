package com.entity;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.entity.layer2.FundTransfer1;
import com.entity.layer2.FundTransfer1;
import com.entity.layer2.Userdetails1;
import com.entity.layer2.Userdetails1;
import com.entity.layer3.Fund_transfer1Repository;
import com.entity.layer3.UserDetailsRepository;

import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootTest
class OnlineBankingApplicationTests {
	
	@Autowired
	UserDetailsRepository b;
	@Autowired
	Fund_transfer1Repository a;
	

	@Test
	void contextLoads() {
	//	List<Fund_Transfer1> get= new ArrayList<Fund_Transfer1>();
		List<FundTransfer1> get=a.getAll();
		
		for(FundTransfer1 as:get)
		{ 
			System.out.println(as.getTransactionid());
		
			System.out.println(as);
		}
	}
	
	@Test
	void testcase()
	{
		Userdetails1 user=new Userdetails1();
		//user.setApplicationDate(null);
		user.setFirstname("Atul");
		user.setLastname("George");
		user.setFathersname("Sanjeev");
		user.setDob(null);
		user.setMobileno("914588618023");
		user.setEMailId("atulgerge@gmail.com");
		user.setAdharcard("453948349500");
		user.setPresAddressline1("336/14-15 Khat Colony");
		user.setPresAddressline2("Nava Wadaj");
		user.setPresCity("Ahmedabad");
		user.setPresState("Gujarat");
		user.setPresZipcode(380013);
		user.setPermAddressline1("139/a Agarwal Estate");
		user.setPermAddressline2("S.v Road Jogeshwari (west)");
		user.setPermCity("Mumbai"); 
		user.setPermCity("Maharashtra");
	   user.setPermZipcode(400102);
		
		b.adduser(user);
		
	}
	

}
